#!/bin/bash

set -e pipefail

CERT_NAME='company'
CA_DIR=$(realpath "${PWD}")

DURATION_DAYS='365'

openssl ecparam -genkey \
-name secp384r1 \
-out "${CERT_NAME}".key

echo -n "
[ req ]
prompt = no
distinguished_name = req_distinguished_name
req_extensions = req_extensions
x509_extensions = req_x509_extensions

[ req_distinguished_name ]
O = Company
CN = supervisely.com

[ req_extensions ]
basicConstraints=critical, CA:FALSE
keyUsage = critical, digitalSignature, keyEncipherment, dataEncipherment

[ req_x509_extensions ]
authorityKeyIdentifier=keyid,issuer
subjectKeyIdentifier = hash
keyUsage = critical, digitalSignature, keyEncipherment, dataEncipherment
extendedKeyUsage = serverAuth, clientAuth
basicConstraints=critical, CA:FALSE
" > "${CERT_NAME}".conf

openssl req -new \
-config "${CERT_NAME}".conf \
-key "${CERT_NAME}".key \
-out "${CERT_NAME}".csr

# With CA
openssl x509 -req -sha256 \
-in "${CERT_NAME}".csr \
-CA "${CA_DIR}/ca.pem" \
-CAkey "${CA_DIR}/ca.key" \
-CAcreateserial \
-out "${CERT_NAME}".pem \
-days "${DURATION_DAYS}" \
-extfile "${CERT_NAME}".conf \
-extensions req_x509_extensions

rm -f full_chain.crt
cat "${CERT_NAME}.pem" "${CA_DIR}/ca.crt" > full_chain.crt
chmod 400 full_chain.crt

rm "${CERT_NAME}".csr "${CERT_NAME}".conf
