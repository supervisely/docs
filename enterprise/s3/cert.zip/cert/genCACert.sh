#!/bin/bash

set -e pipefail

CA_NAME='ca'
CA_CERT_NAME='ca-cert'

DURATION_DAYS='1095'

openssl ecparam -genkey \
-name secp384r1 \
-out "${CA_NAME}".key

echo -n "
[ req ]
prompt = no
distinguished_name = req_distinguished_name
x509_extensions = req_x509_extensions

[ req_distinguished_name ]
CN = Supervisely
OU = supervisely.com
O = Supervisely

[ req_x509_extensions ]
basicConstraints=critical,CA:TRUE
nsCertType = sslCA
extendedKeyUsage = serverAuth, clientAuth, emailProtection, timeStamping, msCodeInd, msCodeCom, msCTLSign, msSGC, msEFS, nsSGC
keyUsage = critical, keyCertSign, cRLSign, digitalSignature
subjectKeyIdentifier = hash
" > "${CA_NAME}".conf

openssl req -new -nodes -sha256 \
-key "${CA_NAME}".key \
-config "${CA_NAME}".conf \
-out "${CA_NAME}".csr

openssl x509 -req -sha256 \
-in "${CA_NAME}".csr \
-signkey "${CA_NAME}".key \
-out "${CA_NAME}".crt \
-days "${DURATION_DAYS}" \
-extfile "${CA_NAME}".conf \
-extensions req_x509_extensions

cat "${CA_NAME}".key "${CA_NAME}".crt > "${CA_NAME}".pem
rm "${CA_NAME}".csr "${CA_NAME}".conf
